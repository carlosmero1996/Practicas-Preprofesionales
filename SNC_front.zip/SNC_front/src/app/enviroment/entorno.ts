export const entorno = {
  urlApi: 'http://localhost:8080/api',
  urlPublica: 'http://localhost:8080/auth',
  urlPrivada: 'http://localhost:8080'
};
