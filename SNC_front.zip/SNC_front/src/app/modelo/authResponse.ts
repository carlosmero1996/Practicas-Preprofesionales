

export class AuthResponse {

  token: string;


  constructor(

    token?: string,

  ) {

    this.token = token || '';

  }
}
